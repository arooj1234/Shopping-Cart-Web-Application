This is a web based shopping store. This is implemented using HTTP, PHP, JavaScript, CSS and Bootstrap. You can run this project by saving all the files in 'htdocs' folder of 'xampp' and run the 'index.php' file.

Web host link: https://18f0347-0239.000webhostapp.com/index.php
